SafeGuard - Android porn blocker (DNS filter VPN)
Build APK: open this folder in Android Studio -> Build -> Build APK(s),
or upload this folder to a GitHub repo -> Actions tab -> "Build APK" -> download SafeGuard-APK.
