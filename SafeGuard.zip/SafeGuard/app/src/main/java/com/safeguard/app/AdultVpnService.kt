package com.safeguard.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

class AdultVpnService : VpnService() {

    companion object {
        const val ACTION_STOP = "com.safeguard.app.STOP"
        var running by mutableStateOf(false)
        private const val FAKE_DNS = "10.111.222.2"
        // CleanBrowsing Family filter DNS: 185.228.168.168
        private val UPSTREAM = byteArrayOf(185.toByte(), 228.toByte(), 168.toByte(), 168.toByte())
    }

    private var tun: ParcelFileDescriptor? = null
    private val pool = Executors.newCachedThreadPool()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setOn(this, false)
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        showForeground()
        Prefs.setOn(this, true)
        startVpn()
        return START_STICKY
    }

    private fun showForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("sg", "Protection", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "sg")
            .setContentTitle("SafeGuard is active")
            .setContentText("Adult websites are blocked")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
    }

    private fun startVpn() {
        if (running) return
        Blocklist.load(this)
        val fd = Builder()
            .setSession("SafeGuard")
            .addAddress("10.111.222.1", 24)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .establish() ?: return
        tun = fd
        running = true
        Thread { runLoop(fd) }.start()
        if (Prefs.autoUpdate(this)) autoUpdate()
    }

    private fun autoUpdate() {
        if (System.currentTimeMillis() - Prefs.lastUpdate(this) < 7L * 86400000L) return
        val app = applicationContext
        Thread {
            try {
                Blocklist.update(app)
                Prefs.setLastUpdate(app)
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun stopVpn() {
        running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onRevoke() {
        stopVpn()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun runLoop(fd: ParcelFileDescriptor) {
        val inp = FileInputStream(fd.fileDescriptor)
        val out = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (true) {
                val n = inp.read(buf)
                if (n < 0) break
                if (n < 28) continue
                if ((buf[0].toInt() shr 4) != 4) continue
                val ihl = (buf[0].toInt() and 0x0F) * 4
                if (buf[9].toInt() != 17 || n < ihl + 8) continue
                if (u16(buf, ihl + 2) != 53) continue
                val srcPort = u16(buf, ihl)
                val plen = u16(buf, ihl + 4) - 8
                if (plen < 12 || ihl + 8 + plen > n) continue
                val dns = buf.copyOfRange(ihl + 8, ihl + 8 + plen)
                val src = buf.copyOfRange(12, 16)
                val dst = buf.copyOfRange(16, 20)
                pool.execute { answer(dns, src, dst, srcPort, out) }
            }
        } catch (_: Exception) {
        } finally {
            if (tun === fd) {
                running = false
            }
        }
    }

    private fun answer(dns: ByteArray, src: ByteArray, dst: ByteArray, srcPort: Int, out: FileOutputStream) {
        try {
            val q = parseQuestion(dns) ?: return
            val resp: ByteArray =
                if (Blocklist.isBlocked(q.first)) blockedReply(dns, q.second) else (forward(dns) ?: return)
            val pkt = buildPacket(dst, src, srcPort, resp)
            synchronized(out) { out.write(pkt) }
        } catch (_: Exception) {
        }
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun parseQuestion(d: ByteArray): Pair<String, Int>? {
        var i = 12
        val sb = StringBuilder()
        while (i < d.size) {
            val l = d[i].toInt() and 0xFF
            if (l == 0) { i++; break }
            if ((l and 0xC0) != 0 || i + 1 + l > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, i + 1, l, Charsets.ISO_8859_1))
            i += 1 + l
        }
        if (i + 4 > d.size) return null
        return Pair(sb.toString().lowercase(), i + 4)
    }

    // Reply "no such domain" (NXDOMAIN) so the site simply won't load.
    private fun blockedReply(d: ByteArray, qEnd: Int): ByteArray {
        val r = d.copyOfRange(0, qEnd)
        r[2] = (0x80 or (d[2].toInt() and 0x01)).toByte()
        r[3] = 0x83.toByte()
        r[4] = 0; r[5] = 1
        for (k in 6..11) r[k] = 0
        return r
    }

    private fun forward(d: ByteArray): ByteArray? {
        val s = DatagramSocket()
        try {
            protect(s)
            s.soTimeout = 4000
            s.send(DatagramPacket(d, d.size, InetAddress.getByAddress(UPSTREAM), 53))
            val b = ByteArray(4096)
            val p = DatagramPacket(b, b.size)
            s.receive(p)
            return b.copyOf(p.length)
        } finally {
            s.close()
        }
    }

    private fun buildPacket(srcIp: ByteArray, dstIp: ByteArray, dstPort: Int, payload: ByteArray): ByteArray {
        val total = 28 + payload.size
        val p = ByteArray(total)
        p[0] = 0x45
        p[2] = (total shr 8).toByte(); p[3] = total.toByte()
        p[6] = 0x40
        p[8] = 64; p[9] = 17
        System.arraycopy(srcIp, 0, p, 12, 4)
        System.arraycopy(dstIp, 0, p, 16, 4)
        var sum = 0L
        for (k in 0 until 20 step 2) sum += ((p[k].toInt() and 0xFF) shl 8) or (p[k + 1].toInt() and 0xFF)
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        val ck = sum.inv().toInt() and 0xFFFF
        p[10] = (ck shr 8).toByte(); p[11] = ck.toByte()
        p[20] = 0; p[21] = 53
        p[22] = (dstPort shr 8).toByte(); p[23] = dstPort.toByte()
        val ul = 8 + payload.size
        p[24] = (ul shr 8).toByte(); p[25] = ul.toByte()
        System.arraycopy(payload, 0, p, 28, payload.size)
        return p
    }
}
