package com.safeguard.app

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Blocklist {
    private const val LIST_URL =
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn-only/hosts"

    @Volatile private var downloaded: Set<String> = emptySet()
    @Volatile private var custom: Set<String> = emptySet()

    private val keywords = listOf(
        "porn", "xvideo", "xnxx", "xhamster", "hentai", "redtube", "youporn", "xxx", "camgirl", "nude"
    )

    private val base: Set<String> = setOf(
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com", "youporn.com",
        "spankbang.com", "eporner.com", "tube8.com", "beeg.com", "tnaflix.com", "txxx.com",
        "hclips.com", "porn.com", "brazzers.com", "naughtyamerica.com", "realitykings.com",
        "chaturbate.com", "stripchat.com", "bongacams.com", "livejasmin.com", "cam4.com",
        "myfreecams.com", "rule34.xxx", "e-hentai.org", "nhentai.net", "hentaihaven.xxx",
        "motherless.com", "4tube.com", "thumbzilla.com", "fapello.com", "fapster.xxx",
        "xtube.com", "sunporno.com", "drtuber.com", "hqporner.com", "pornone.com",
        "ixxx.com", "daftsex.com", "efukt.com", "erome.com", "luscious.net"
    )

    fun load(ctx: Context) {
        custom = Prefs.custom(ctx)
        val f = File(ctx.filesDir, "list.txt")
        if (f.exists()) downloaded = f.readLines().filter { it.isNotBlank() }.toHashSet()
    }

    fun setCustom(s: Set<String>) { custom = s }

    fun clean(input: String): String? {
        var d = input.trim().lowercase()
        d = d.removePrefix("https://").removePrefix("http://").removePrefix("www.")
        d = d.substringBefore('/').substringBefore('?').substringBefore(':')
        return if (d.contains('.') && !d.contains(' ')) d else null
    }

    fun isBlocked(name: String): Boolean {
        var d = name.trimEnd('.')
        if (d.isEmpty()) return false
        if (keywords.any { d.contains(it) }) return true
        while (true) {
            if (d in base || d in custom || d in downloaded) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    fun update(ctx: Context): Int {
        val c = URL(LIST_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        val set = HashSet<String>()
        c.inputStream.bufferedReader().useLines { lines ->
            lines.forEach { l ->
                val t = l.trim()
                if (t.startsWith("0.0.0.0 ") || t.startsWith("127.0.0.1 ")) {
                    val dom = t.substringAfter(' ').substringBefore('#').trim().lowercase()
                    if (dom.contains('.') && dom != "0.0.0.0") set.add(dom)
                }
            }
        }
        if (set.size < 100) throw IllegalStateException("bad list")
        File(ctx.filesDir, "list.txt").writeText(set.joinToString("\n"))
        downloaded = set
        return set.size
    }
}
