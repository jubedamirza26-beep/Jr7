package com.safeguard.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Prefs.wantOn(c) && VpnService.prepare(c) == null) {
            ContextCompat.startForegroundService(c, Intent(c, AdultVpnService::class.java))
        }
    }
}
