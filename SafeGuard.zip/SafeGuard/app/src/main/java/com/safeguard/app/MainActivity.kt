package com.safeguard.app

import android.Manifest
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) startProtection()
        }
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun startProtection() {
        ContextCompat.startForegroundService(this, Intent(this, AdultVpnService::class.java))
    }

    private fun enable() {
        val i = VpnService.prepare(this)
        if (i != null) vpnPermission.launch(i) else startProtection()
    }

    private fun disable() {
        startService(Intent(this, AdultVpnService::class.java).setAction(AdultVpnService.ACTION_STOP))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { SafeGuardApp({ enable() }, { disable() }) }
    }
}

@Composable
fun SafeGuardApp(onEnable: () -> Unit, onDisable: () -> Unit) {
    val ctx = LocalContext.current
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            var hasPin by remember { mutableStateOf(Prefs.hasPin(ctx)) }
            if (!hasPin) {
                SetupPin { Prefs.setPin(ctx, it); hasPin = true }
            } else {
                Home(onEnable, onDisable)
            }
        }
    }
}

@Composable
fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) onChange(it) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun SetupPin(onDone: (String) -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Set a 4-digit PIN", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("You will need this PIN to turn protection off.")
        Spacer(Modifier.height(16.dp))
        PinField("PIN", a) { a = it }
        Spacer(Modifier.height(8.dp))
        PinField("Confirm PIN", b) { b = it }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onDone(a) }, enabled = a.length == 4 && a == b) { Text("Save PIN") }
    }
}

@Composable
fun PinDialog(wrong: Boolean, onCancel: () -> Unit, onPin: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Enter PIN") },
        text = {
            Column {
                PinField("PIN", pin) { pin = it }
                if (wrong) Text("Wrong PIN", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = { onPin(pin); pin = "" }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

@Composable
fun Home(onEnable: () -> Unit, onDisable: () -> Unit) {
    val ctx = LocalContext.current
    val on = AdultVpnService.running
    var pinAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var wrong by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf(Prefs.custom(ctx).sorted()) }
    var site by remember { mutableStateOf("") }
    var auto by remember { mutableStateOf(Prefs.autoUpdate(ctx)) }
    var status by remember { mutableStateOf("") }

    LazyColumn(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Spacer(Modifier.height(40.dp))
            Text("SafeGuard", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(if (on) "Protection is ON" else "Protection is OFF")
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { if (on) { pinAction = onDisable } else { onEnable() } },
                modifier = Modifier.size(180.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (on) Color(0xFF2E7D32) else Color(0xFFC62828)
                )
            ) { Text(if (on) "ON" else "OFF", fontSize = 32.sp) }
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = auto, onCheckedChange = { auto = it; Prefs.setAutoUpdate(ctx, it) })
                Spacer(Modifier.width(8.dp))
                Text("Auto-update block list weekly")
            }
            OutlinedButton(onClick = {
                status = "Updating..."
                val app = ctx.applicationContext
                Thread {
                    status = try {
                        val n = Blocklist.update(app)
                        Prefs.setLastUpdate(app)
                        "Updated: $n sites"
                    } catch (e: Exception) {
                        "Update failed (is protection on and internet working?)"
                    }
                }.start()
            }) { Text("Update block list now") }
            if (status.isNotEmpty()) Text(status)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = site,
                onValueChange = { site = it },
                label = { Text("Add a site (example.com)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                val d = Blocklist.clean(site)
                if (d != null) {
                    Prefs.addCustom(ctx, d)
                    Blocklist.setCustom(Prefs.custom(ctx))
                    custom = Prefs.custom(ctx).sorted()
                    site = ""
                }
            }) { Text("Block this site") }
            Spacer(Modifier.height(16.dp))
        }
        items(custom) { d ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(d)
                TextButton(onClick = {
                    pinAction = {
                        Prefs.removeCustom(ctx, d)
                        Blocklist.setCustom(Prefs.custom(ctx))
                        custom = Prefs.custom(ctx).sorted()
                    }
                }) { Text("Remove") }
            }
        }
    }

    pinAction?.let { act ->
        PinDialog(wrong, { pinAction = null; wrong = false }) { pin ->
            if (Prefs.checkPin(ctx, pin)) {
                pinAction = null
                wrong = false
                act()
            } else {
                wrong = true
            }
        }
    }
}
