package com.safeguard.app

import android.content.Context
import java.security.MessageDigest

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("safeguard", Context.MODE_PRIVATE)

    private fun hash(p: String): String =
        MessageDigest.getInstance("SHA-256").digest(("sg_salt_" + p).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(c: Context) = sp(c).contains("pin")
    fun setPin(c: Context, p: String) = sp(c).edit().putString("pin", hash(p)).apply()
    fun checkPin(c: Context, p: String) = sp(c).getString("pin", null) == hash(p)

    fun wantOn(c: Context) = sp(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()

    fun autoUpdate(c: Context) = sp(c).getBoolean("auto", true)
    fun setAutoUpdate(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()

    fun lastUpdate(c: Context) = sp(c).getLong("last", 0L)
    fun setLastUpdate(c: Context) = sp(c).edit().putLong("last", System.currentTimeMillis()).apply()

    fun custom(c: Context): Set<String> = HashSet(sp(c).getStringSet("custom", emptySet()) ?: emptySet())
    fun addCustom(c: Context, d: String) = sp(c).edit().putStringSet("custom", custom(c) + d).apply()
    fun removeCustom(c: Context, d: String) = sp(c).edit().putStringSet("custom", custom(c) - d).apply()
}
